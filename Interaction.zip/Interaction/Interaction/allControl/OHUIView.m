//
//  OHUIView.m
//  Interaction
//
//  Created by KT-yzx on 2019/9/20.
//  Copyright © 2019 QuickTo. All rights reserved.
//

#import "OHUIView.h"

@implementation OHUIView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

- (id)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        
    }
    return self;
}

- (void)oh_backgroundColor:(int)hexValue{
    self.backgroundColor = COLOR_HEX(hexValue);
}

@end
