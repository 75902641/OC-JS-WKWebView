//
//  AppDelegate.h
//  Interaction
//
//  Created by KT-yzx on 2019/9/20.
//  Copyright © 2019 QuickTo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

